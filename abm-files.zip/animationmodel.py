import random
import matplotlib.pyplot
import agentframework
import csv
from sys import argv
import matplotlib.animation


#create command line arguments for number of agents, iterations and neighbourhood size
num_of_agents = int(argv[1])
num_of_iterations = int(argv[2])
neighbourhood = int(argv[3])


#read file to create environment
environment = []
f = open('in.txt', newline='')
reader = csv.reader(f, quoting=csv.QUOTE_NONNUMERIC)
for row in reader:
    rowlist = []
    for item in row:
        rowlist.append(item)
    environment.append(rowlist)
f.close()

#create a list for agents
agents = []

#create agents
for i in range(num_of_agents):
    agents.append(agentframework.Agent(environment, agents))

#randomly shuffle agents' order in the list
random.shuffle(agents)

#create figure for animation
fig = matplotlib.pyplot.figure(figsize=(7,7))
ax = fig.add_axes([0, 0, 1, 1])
ax.set_autoscale_on(False)

#define the code to be animated
def update(frame_number):
    fig.clear()
    matplotlib.pyplot.imshow(environment)

    #for each iteration, make the agents move, eat, vomit and share with neighbours
    for j in range(num_of_iterations):
        for i in range(num_of_agents):
            agents[i].move()
            agents[i].eat()
            agents[i].vomit()
            agents[i].share_with_neighbours(neighbourhood)   
    for i in range(num_of_agents):
        matplotlib.pyplot.scatter(agents[i]._x, agents[i]._y, color='red', edgecolor='black')
    
        
#Show animation
animation = matplotlib.animation.FuncAnimation(fig, update, interval=1, repeat=False, frames=num_of_iterations)
matplotlib.pyplot.show()