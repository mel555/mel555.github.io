import random

class Agent():
    #define initial attributes of agents
    def __init__ (self, environment, agents):
        #designate the x and y coordinates of agents as random points within a grid the size of the environment
        self._x = random.randint(0,len(environment))
        self._y = random.randint(0,len(environment))
        #store the environment within each agent
        self.environment = environment
        #create a store for each agent which is initially empty
        self.store = 0
        #store the list of other agents within each agent
        self.agents = agents
        
    #define method for calculating distance between agents
    def distance_between(self, agent):
        return((self._x-agent._x)**2 + (self._y-agent._y)**2)**0.5
        
    #define method where agents move depending on a random number, reappearing on the other side if they leave the grid boundaries
    #If agents have a higher amount of resources in their store they move by two spaces
    def move(self):
        if self.store < 500:
            if random.random() < 0.5:
                self._x = (self._x + 1) % 300
            else:
                self._x = (self._x - 1) % 300
            if random.random() < 0.5:
                self._y = (self._y + 1) % 300
            else:
                self._y = (self._y - 1) % 300
        else:
            if random.random() < 0.5:
                self._x = (self._x + 2) % 300
            else:
                self._x = (self._x - 2) % 300
            if random.random() < 0.5:
                self._y = (self._y + 2) % 300
            else:
                self._y = (self._y - 2) % 300
    
    #Implement property attributes
    def get_x(self):
        return self._x
    def set_x(self,value):
        self._x = value
    def del_x(self):
        del self._x
    
    def get_y(self):
        return self._y
    def set_y(self,value):
        self._y = value
    def del_y(self):
        del self._y
    
    #define method for eating: 10 units at a time, or everything if the environment is less than 10
    #Eaten food goes into the store
    def eat(self):
        if self.environment[self._y][self._x] > 10:
            self.environment[self._y][self._x] -= 10
            self.store += 10
        else:
            self.store += (self.environment[self._y][self._x])            
            self.environment[self._y][self._x] -= (self.environment[self._y][self._x])
    
    #override the string method to show coordinates and stores of agents
    def __str__ (self):
        return "coordinates: " + str(self._x) + "," + str(self._y) + " stores: " + str(self.store)
    
    #define method for agents to vomit their stores back into the environment if they exceed 1000
    def vomit(self):
        if self.store > 1000:
            self.environment[self._x][self._y] += self.store
            self.store -= self.store
    
    #define method for sharing stores with other agents in the neighbourhood
    def share_with_neighbours(self, neighbourhood):
        for agent in self.agents:
            distance = self.distance_between(agent)
            if distance <= neighbourhood:
                average = (self.store + agent.store)/2
                self.store = average
                agent.store = average